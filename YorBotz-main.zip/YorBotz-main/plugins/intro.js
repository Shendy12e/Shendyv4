let handler = async m => {

conn.relayMessage(m.chat,  {
    requestPaymentMessage: {
      currencyCodeIso4217: 'INR',
      amount1000: 1339889,
      requestFrom: m.sender,
      noteMessage: {
      extendedTextMessage: {
      text: `
0ཻུ۪۪ꦽꦼ̷⸙‹•══════════════♡᭄
│       *「 Kartu Intro 」*
│ *Nama     :* 
│ *Gender   :* 
│ *Umur     :* 
│ *Hobby    :* 
│ *Kelas    :* 
│ *Asal     :* 
│ *Agama    :* 
| *Status   :* 
╰═════ꪶ ཻུ۪۪ꦽꦼ̷⸙ ━ ━ ━ ━ ꪶ ཻུ۪۪ꦽꦼ̷⸙
`,
      contextInfo: {
      externalAdReply: {
      showAdAttribution: true
      }}}}}}, {})

}
handler.command = /^(intro)$/i

module.exports = handler
